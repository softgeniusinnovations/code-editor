var i,a;function d(){if(a)return i;a=1,i=n;function n(r){var e=typeof r=="string"?r.charCodeAt(0):r;return e>=97&&e<=102||e>=65&&e<=70||e>=48&&e<=57}return i}export{d as r};
