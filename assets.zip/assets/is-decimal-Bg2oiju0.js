var r,n;function u(){if(n)return r;n=1,r=t;function t(e){var i=typeof e=="string"?e.charCodeAt(0):e;return i>=48&&i<=57}return r}export{u as r};
