var a,i;function l(){if(i)return a;i=1,a=t;function t(r){var e=typeof r=="string"?r.charCodeAt(0):r;return e>=97&&e<=122||e>=65&&e<=90}return a}export{l as r};
