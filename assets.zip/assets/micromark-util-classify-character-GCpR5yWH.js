import{i,u as a,j as r}from"./micromark-util-character-Ch8j4vtg.js";function u(n){if(n===null||i(n)||a(n))return 1;if(r(n))return 2}export{u as c};
