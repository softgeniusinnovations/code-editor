const r=document.createElement("i");function c(t){const n="&"+t+";";r.innerHTML=n;const e=r.textContent;return e.charCodeAt(e.length-1)===59&&t!=="semi"||e===n?!1:e}export{c as d};
